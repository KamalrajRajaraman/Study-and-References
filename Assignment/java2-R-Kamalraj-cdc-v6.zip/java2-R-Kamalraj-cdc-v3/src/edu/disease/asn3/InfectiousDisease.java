package edu.disease.asn3;



public class InfectiousDisease extends  Disease{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String[] getExamples() {
		return new String[] {"InfectiousDisease1","InfectiousDisease2","InfectiousDisease3","InfectiousDisease4"};
	}

}
