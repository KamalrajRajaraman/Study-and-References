package edu.disease.asn2;



public class InfectiousDisease extends  Disease{
	
	
	@Override
	public String[] getExamples() {
		return new String[] {"InfectiousDisease1","InfectiousDisease2","InfectiousDisease3","InfectiousDisease4"};
	}

}
