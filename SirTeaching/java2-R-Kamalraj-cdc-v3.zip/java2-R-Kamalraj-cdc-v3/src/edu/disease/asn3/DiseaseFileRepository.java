package edu.disease.asn3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class DiseaseFileRepository {
	private String folderPath;
	private Disease[] disease;
	private Patient[] patient;
	public void save(Disease[] disease,Patient[] patient) throws IOException {
		FileOutputStream fos1 = new FileOutputStream(folderPath+"\\diseases.dat");
		ObjectOutputStream oos1 = new ObjectOutputStream(fos1);
		oos1.writeObject(disease);
		
		FileOutputStream fos2 = new FileOutputStream(folderPath+"\\patients.dat");
		ObjectOutputStream oos2 = new ObjectOutputStream(fos2);
		oos2.writeObject(patient);
	}
	public DiseaseAndPatient  init(String folderPath) throws ClassNotFoundException, IOException {
		this.folderPath=folderPath;
		File f1 = new File(folderPath+"\\diseases.dat");
		DiseaseAndPatient dp = new DiseaseAndPatient();
		
		
		if(f1.exists()) {
			FileInputStream fis1 = new FileInputStream(folderPath+"\\diseases.dat");
			ObjectInputStream ois1 =  new ObjectInputStream(fis1);
			dp.setDiseases((Disease[]) ois1.readObject());
		}
	
		File f2 = new File(folderPath+"\\patients.dat");
		if(f2.exists()) {
			FileInputStream fis2 = new FileInputStream(folderPath+"\\patients.dat");
			ObjectInputStream ois2 =  new ObjectInputStream(fis2);
			dp.setPatient((Patient[]) ois2.readObject());
		}
		
		
		return dp;
		
	}
}

